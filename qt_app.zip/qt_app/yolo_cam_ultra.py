#!/usr/bin/env python3
"""
YOLO11 RKNN - Real-time Camera Inference using Ultralytics API
Model: yolo11n_rknn_model/
Camera: /dev/video21 + GStreamer fallback
"""
import sys
import os as _os
_SCRIPT_DIR = _os.path.dirname(_os.path.abspath(__file__))
_py_pkgs = _os.path.join(_SCRIPT_DIR, "python_packages")
if _py_pkgs not in sys.path:
    sys.path.insert(0, _py_pkgs)

import cv2
import time
import subprocess as sp
from ultralytics import YOLO

print("cv2 version:", cv2.__version__)

# ============================================================
# Config
# ============================================================
MODEL_PATH = "/userdata/hand/yolo11n_rknn_model"
CONF_THRESH = 0.25

# ============================================================
# Load model
# ============================================================
print("Loading RKNN model...")
model = YOLO(MODEL_PATH, task="detect")
print("Model loaded")

# ============================================================
# Camera
# ============================================================
print("Starting camera...")
sp.run("echo elf | sudo -S systemctl restart rkaiq_3A", shell=True, capture_output=True)
time.sleep(2)

GST_PIPE = (
    "v4l2src device=/dev/video12 ! "
    "video/x-raw,format=NV12,width=640,height=480,framerate=30/1 ! "
    "videoconvert ! video/x-raw,format=BGR ! "
    "appsink drop=1 max-buffers=1"
)
cap = cv2.VideoCapture(GST_PIPE, cv2.CAP_GSTREAMER)
if not cap.isOpened():
    cap = cv2.VideoCapture(11)
if not cap.isOpened():
    cap = cv2.VideoCapture("/dev/video21")
    cap.set(3,800)
    cap.set(4,480)
if not cap.isOpened():
    cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("ERROR: Cannot open camera")
    exit(1)
print("Camera OK")

# ============================================================
# Main loop
# ============================================================
print("Running... Press q or ESC to quit")
prev_time = time.time()
fps = 0

try:
    while cap.isOpened():
        success, frame = cap.read()
        if not success:
            continue

        # Run inference
        results = model(frame, conf=CONF_THRESH, verbose=False)

        # Draw results
        annotated = results[0].plot()

        # Real-time FPS (update every frame with smoothing)
        curr_time = time.time()
        elapsed = curr_time - prev_time
        prev_time = curr_time
        fps = 0.9 * fps + 0.1 * (1.0 / elapsed) if elapsed > 0 else fps

        cv2.putText(annotated, "YOLO11n RKNN  FPS:{:.1f}".format(fps), (5, 25),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

        cv2.imshow("YOLO11n RKNN", annotated)

        key = cv2.waitKey(5) & 0xFF
        if key == ord("q") or key == 27:
            break

finally:
    cap.release()
    cv2.destroyAllWindows()
    cv2.waitKey(1)

print("Exit")

