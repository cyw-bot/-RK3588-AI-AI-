# 仿生手臂 - STM32 舵机控制系统

基于 STM32F103C8T6 的五自由度仿生机械手，通过 UART 串口接收手势指令，驱动 5 路 SG90 舵机实现手指独立动作。

## 文件结构

```
仿生手臂/
├── 3D打印件/              # 25个STL文件，可3D打印的机械手零件
│   ├── thumb5.stl         # 拇指
│   ├── Index3.stl         # 食指
│   ├── Majeure3.stl       # 中指
│   ├── ringfinger3.stl    # 无名指
│   ├── Auriculaire3.stl   # 小指
│   ├── robpart*.stl       # 手掌/底座部件
│   ├── RobServoBedV6.stl  # 舵机安装座
│   ├── Wrist*.stl         # 手腕旋转机构
│   └── ...
├── 舵机/
│   ├── User/              # 用户代码
│   │   ├── main.c         # 主程序 - 手势控制与游戏逻辑
│   │   ├── stm32f10x_conf.h
│   │   └── stm32f10x_it.c/h
│   ├── System/            # 驱动模块
│   │   ├── chuanko.c/h    # UART串口通信 + 数据帧解析
│   │   ├── PWM.c/h        # 舵机PWM驱动
│   │   ├── Fingers.c/h    # 五手指独立控制
│   │   ├── S.c/h          # 石���剪刀布游戏逻辑
│   │   ├── OLED.c/h       # OLED显示屏驱动
│   │   ├── Delay.c/h      # 延时函数
│   │   ├── Store.c/h      # 数据存储
│   │   └── Yuyin.c/h      # 语音模块驱动
│   ├── Library/           # STM32标准外设库（仅需模块）
│   │   ├── stm32f10x_gpio.c/h
│   │   ├── stm32f10x_tim.c/h
│   │   ├── stm32f10x_usart.c/h
│   │   ├── stm32f10x_rcc.c/h
│   │   └── misc.c/h
│   ├── Start/             # 启动文件
│   │   ├── startup_stm32f10x_md.s
│   │   ├── core_cm3.c/h
│   │   └── system_stm32f10x.c/h
│   └── project.uvprojx    # Keil MDK 工程文件
```

## 硬件连接

| STM32 引脚 | 连接 | 功能 |
|-----------|------|------|
| PA9 (USART1_TX) | RK3588 UART9_RX | 调试输出 |
| PA10 (USART1_RX) | RK3588 UART9_TX | 接收手势数据 |
| PB10 (USART3_TX) | RK3588 UART_RX（预留） | 游戏结果回传 |
| PB11 (USART3_RX) | RK3588 UART_TX（预留） | 接收命令模式 |
| PA0 (TIM2_CH1) | 舵机1 | 拇指 |
| PA1 (TIM2_CH2) | 舵机2 | 食指 |
| PA2 (TIM2_CH3) | 舵机3 | 中指 |
| PA3 (TIM2_CH4) | 舵机4 | 无名指 |
| PA6 (TIM3_CH1) | 舵机5 | 小指 |

## 通信协议

### 手势数据帧（USART1 接收）

```
┌────────┬─────────────┬────────┐
│ 0x2C   │ 5 bytes     │ 0x5B   │
│ 帧头   │ 手指状态     │ 帧尾   │
└────────┴─────────────┴────────┘

手指状态: x1=拇指, x2=食指, x3=中指, x4=无名指, x5=小指
0 = 弯曲, 1 = 伸直
```

### 命令模式（USART3 接收）

| 命令 | 功能 |
|------|------|
| 0x01 | 石头剪刀布游戏模式 |
| 0x02 | 普通手势模式 |
| 0x03 | OK手势 |
| 0x04 | 张开手掌 |
| 0x05 | 握拳 |

### 游戏结果（USART3 回传）

| 数据 | 含义 |
|------|------|
| 0x01 | AI 获胜 |
| 0x02 | 玩家获胜 |
| 0x03 | 平局 |
| 0x04 | 无效手势 |
| 0x05 | 默认 |

## 运行环境

- MCU: STM32F103C8T6
- 伺服舵机: SG90 × 5
- 编译器: Keil MDK-ARM V5
- 固件库: STM32F10x Standard Peripheral Library V3.5

## 与 RK3588 主控的联动

```
RK3588 (Qt UI)
    │
    │ MediaPipe 手势识别 → 五指状态
    │
    ▼
UART9 TX → PA10(RX)
    │
    │ 数据帧: 0x2C + [x1][x2][x3][x4][x5] + 0x5B
    │
    ▼
STM32 解析
    │
    ├─→ 5路 PWM → SG90舵机 → 手指动作
    ├─→ OLED 显示手指状态
    └─→ 游戏模式: 石头剪刀布判定
```
