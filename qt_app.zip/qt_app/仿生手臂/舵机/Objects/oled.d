.\objects\oled.o: System\OLED.c
.\objects\oled.o: .\Start\stm32f10x.h
.\objects\oled.o: .\Start\core_cm3.h
.\objects\oled.o: F:\keil5_32\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\oled.o: .\Start\system_stm32f10x.h
.\objects\oled.o: .\User\stm32f10x_conf.h
