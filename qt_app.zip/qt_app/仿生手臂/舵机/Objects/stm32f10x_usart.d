.\objects\stm32f10x_usart.o: Library\stm32f10x_usart.c
.\objects\stm32f10x_usart.o: Library\stm32f10x_usart.h
.\objects\stm32f10x_usart.o: .\Start\stm32f10x.h
.\objects\stm32f10x_usart.o: .\Start\core_cm3.h
.\objects\stm32f10x_usart.o: F:\keil5_32\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\stm32f10x_usart.o: .\Start\system_stm32f10x.h
.\objects\stm32f10x_usart.o: .\User\stm32f10x_conf.h
