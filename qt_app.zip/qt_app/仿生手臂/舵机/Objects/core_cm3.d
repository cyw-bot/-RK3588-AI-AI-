.\objects\core_cm3.o: Start\core_cm3.c
.\objects\core_cm3.o: F:\keil5_32\ARM\ARMCC\Bin\..\include\stdint.h
