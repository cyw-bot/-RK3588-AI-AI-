.\objects\chuanko.o: System\chuanko.c
.\objects\chuanko.o: .\Start\stm32f10x.h
.\objects\chuanko.o: .\Start\core_cm3.h
.\objects\chuanko.o: F:\keil5_32\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\chuanko.o: .\Start\system_stm32f10x.h
.\objects\chuanko.o: .\User\stm32f10x_conf.h
