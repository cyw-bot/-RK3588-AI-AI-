.\objects\s.o: System\S.c
.\objects\s.o: .\Start\stm32f10x.h
.\objects\s.o: .\Start\core_cm3.h
.\objects\s.o: F:\keil5_32\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\s.o: .\Start\system_stm32f10x.h
.\objects\s.o: .\User\stm32f10x_conf.h
