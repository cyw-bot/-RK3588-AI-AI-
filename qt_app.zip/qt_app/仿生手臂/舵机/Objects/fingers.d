.\objects\fingers.o: System\Fingers.c
.\objects\fingers.o: .\Start\stm32f10x.h
.\objects\fingers.o: .\Start\core_cm3.h
.\objects\fingers.o: F:\keil5_32\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\fingers.o: .\Start\system_stm32f10x.h
.\objects\fingers.o: .\User\stm32f10x_conf.h
