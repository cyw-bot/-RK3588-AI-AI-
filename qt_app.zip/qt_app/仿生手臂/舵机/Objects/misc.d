.\objects\misc.o: Library\misc.c
.\objects\misc.o: Library\misc.h
.\objects\misc.o: .\Start\stm32f10x.h
.\objects\misc.o: .\Start\core_cm3.h
.\objects\misc.o: F:\keil5_32\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\misc.o: .\Start\system_stm32f10x.h
.\objects\misc.o: .\User\stm32f10x_conf.h
