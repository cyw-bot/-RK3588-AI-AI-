#include "stm32f10x.h"                  // Device header
#include "Delay.h"

void PWM_Init(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_6|GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	//TIM2
	TIM_InternalClockConfig(TIM2);
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStructure.TIM_Period = 20000-1 ;	//ARR
	TIM_TimeBaseInitStructure.TIM_Prescaler = 72-1 ;	//PSC
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM2,&TIM_TimeBaseInitStructure);
	//TIM3
	TIM_InternalClockConfig(TIM3);
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStructure.TIM_Period = 20000-1 ;	//ARR
	TIM_TimeBaseInitStructure.TIM_Prescaler = 72-1 ;	//PSC
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM3,&TIM_TimeBaseInitStructure);
	
	TIM_OCInitTypeDef TIM_OCInitStructure;
	TIM_OCStructInit(&TIM_OCInitStructure);
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OCInitStructure.TIM_Pulse = 0;
	TIM_OC2Init(TIM2,&TIM_OCInitStructure);
	TIM_OC3Init(TIM2,&TIM_OCInitStructure);
	TIM_OC4Init(TIM2,&TIM_OCInitStructure);
	TIM_OC1Init(TIM3,&TIM_OCInitStructure);
	TIM_OC2Init(TIM3,&TIM_OCInitStructure);
	
	TIM_Cmd(TIM2,ENABLE);
	TIM_Cmd(TIM3,ENABLE);
}


void Fingers1(uint16_t Compare)
{
	TIM_SetCompare1(TIM3,Compare);
}
void Fingers2(uint16_t Compare)
{
	TIM_SetCompare2(TIM3,Compare);
}
void Fingers3(uint16_t Compare)
{
	TIM_SetCompare2(TIM2,Compare);
}
void Fingers4(uint16_t Compare)
{
	TIM_SetCompare3(TIM2,Compare);
}
void Fingers5(uint16_t Compare)
{
	TIM_SetCompare4(TIM2,Compare);
}

void Servo_SetFingers1(float Angle1)
{
	Fingers1(Angle1 / 180 * 2000 + 500);
}
void Servo_SetFingers2(float Angle2)
{
	Fingers2(Angle2 / 180 * 2000 + 500);
}
void Servo_SetFingers3(float Angle3)
{
	Fingers3(Angle3 / 180 * 2000 + 500);
}
void Servo_SetFingers4(float Angle4)
{
	Fingers4(Angle4 / 180 * 2000 + 500);
}
void Servo_SetFingers5(float Angle5)
{
	Fingers5(Angle5 / 180 * 2000 + 500);
}

void Servo_Init(void)
{
		Servo_SetFingers5(143);      //��Ĵָ 50-143
		Servo_SetFingers1(160);      //ʳָ   60-160
		Servo_SetFingers4(175);      //��ָ   60-175
		Servo_SetFingers3(160);      //����ָ 65-160
		Servo_SetFingers2(160);      //СĴָ 65-160
		Delay_ms(1500);
	  Servo_SetFingers5(50);      //��Ĵָ 50-143
	  Servo_SetFingers1(60);      //ʳָ   60-160
	  Servo_SetFingers4(60);      //��ָ   60-175
		Servo_SetFingers3(65);      //����ָ 65-160
		Servo_SetFingers2(65);      //СĴָ 65-160
}
