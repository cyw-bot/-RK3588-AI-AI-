#ifndef _S_H
#define _S_H

void TIM4_Init(void);
uint8_t random_1_to_3(void);

#endif
