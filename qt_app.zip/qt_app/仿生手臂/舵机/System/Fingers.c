#include "stm32f10x.h"                 
#include "PWM.h"
#include "Delay.h"
#include "Fingers.h"

#include "stm32f10x.h"
#include "PWM.h"
#include "Delay.h"
#include "Fingers.h"

#define STEP_DELAY   30      // ÿ�ζ��ļ��
#define START_OFFSET 400      // ÿ����ָ�������

// ��ָ�ǶȽṹ
typedef struct {
    float cur, target;
    int start_delay;  // �����ӳ٣����룩
} FingerMove;

//======================
// ��ָͬʱƽ���ƶ�������������
//======================
void Fingers_Move_Stagger(float t_start, float t_end,
                          float i_start, float i_end,
                          float m_start, float m_end,
                          float r_start, float r_end,
                          float p_start, float p_end)
{
    FingerMove F[5] = {
        {t_start, t_end, 0},
        {i_start, i_end, START_OFFSET},
        {m_start, m_end, START_OFFSET*2},
        {r_start, r_end, START_OFFSET*3},
        {p_start, p_end, START_OFFSET*4},
    };

    int all_done;

    for(int time = 0; ; time += STEP_DELAY)
    {
        all_done = 1;

        // ��Ĵָ
        if(time >= F[0].start_delay && F[0].cur != F[0].target){
            F[0].cur += (F[0].cur < F[0].target) ? 1 : -1;
            Servo_SetFingers5(F[0].cur);
            all_done = 0;
        }
        // ʳָ
        if(time >= F[1].start_delay && F[1].cur != F[1].target){
            F[1].cur += (F[1].cur < F[1].target) ? 1 : -1;
            Servo_SetFingers1(F[1].cur);
            all_done = 0;
        }
        // ��ָ
        if(time >= F[2].start_delay && F[2].cur != F[2].target){
            F[2].cur += (F[2].cur < F[2].target) ? 1 : -1;
            Servo_SetFingers4(F[2].cur);
            all_done = 0;
        }
        // ����ָ
        if(time >= F[3].start_delay && F[3].cur != F[3].target){
            F[3].cur += (F[3].cur < F[3].target) ? 1 : -1;
            Servo_SetFingers3(F[3].cur);
            all_done = 0;
        }
        // СĴָ
        if(time >= F[4].start_delay && F[4].cur != F[4].target){
            F[4].cur += (F[4].cur < F[4].target) ? 1 : -1;
            Servo_SetFingers2(F[4].cur);
            all_done = 0;
        }

        if(all_done) break;
        Delay_ms(STEP_DELAY);
    }
}

//======================
// ��ָ�����ſ�
//======================
void Fingers_Open_Smooth(void)
{
    Fingers_Move_Stagger(
        THUMB_MIN, THUMB_MAX,
        INDEX_MIN, INDEX_MAX,
        MIDDLE_MIN, MIDDLE_MAX,
        RING_MIN,   RING_MAX,
        PINKY_MIN,  PINKY_MAX
    );
}

//======================
// ��ָ�����ջ�
//======================
void Fingers_Close_Smooth(void)
{
    Fingers_Move_Stagger(
        THUMB_MAX, THUMB_MIN,
        INDEX_MAX, INDEX_MIN,
        MIDDLE_MAX, MIDDLE_MIN,
        RING_MAX,   RING_MIN,
        PINKY_MAX,  PINKY_MIN
    );
}

void Hand_Action(void)
{
		Fingers_Open_Smooth();   // ��ָ����ƽ���ſ�
    Delay_ms(10);
    Fingers_Close_Smooth();  // ��ָ����ƽ���ջ�
		Delay_ms(10);
}
