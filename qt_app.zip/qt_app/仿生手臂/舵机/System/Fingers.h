#ifndef _FINGERS_H
#define _FINGERS_H

#define THUMB_MIN   50
#define THUMB_MAX   143

#define INDEX_MIN   60
#define INDEX_MAX   165

#define MIDDLE_MIN  60
#define MIDDLE_MAX  175

#define RING_MIN    65
#define RING_MAX    160

#define PINKY_MIN   65
#define PINKY_MAX   160


void Fingers_Move_Stagger(float t_start, float t_end,
                          float i_start, float i_end,
                          float m_start, float m_end,
                          float r_start, float r_end,
                          float p_start, float p_end);

void Fingers_Open_Smooth(void);
void Fingers_Close_Smooth(void);
void Hand_Action(void);

#endif
