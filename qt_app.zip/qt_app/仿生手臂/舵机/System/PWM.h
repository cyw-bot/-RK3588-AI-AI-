#ifndef _PWM_H
#define _PWM_H
	
void PWM_Init(void);
void Fingers1(uint16_t Compare);
void Fingers2(uint16_t Compare);
void Fingers3(uint16_t Compare);
void Fingers4(uint16_t Compare);
void Fingers5(uint16_t Compare);
void Servo_SetFingers1(float Angle1);
void Servo_SetFingers2(float Angle2);
void Servo_SetFingers3(float Angle3);
void Servo_SetFingers4(float Angle4);
void Servo_SetFingers5(float Angle5);
void Servo_Init(void);

#endif
