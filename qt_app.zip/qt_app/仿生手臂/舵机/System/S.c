#include "stm32f10x.h"                 

void TIM4_Init(void)
{
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);

    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    TIM_TimeBaseStructure.TIM_Period = 0xFFFF;      
    TIM_TimeBaseStructure.TIM_Prescaler = 71;       // 72MHz / 72 = 1MHz��1us �� 1��
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;

    TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);

    TIM_Cmd(TIM4, ENABLE);  // ʹ�ܶ�ʱ��
}

uint8_t random_1_to_3(void)
{
    uint16_t cnt = TIM4->CNT;   // ��ȡ������ֵ
    return (cnt % 3) + 1;       // ת��Ϊ 1~3
}
