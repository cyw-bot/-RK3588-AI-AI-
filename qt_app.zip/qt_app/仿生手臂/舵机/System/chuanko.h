#ifndef _CHUANKO_H
#define _CHUANKO_H

#define RX_BUFFER_SIZE 64

#include <stdio.h>

void USART1_Init(void);
void Serial_SendByte(uint8_t Byte);
void USART1_IRQHandler(void);
void Process_Received_Data(void);
int fputc(int ch, FILE *f);
int fgetc(FILE *f);

#endif
