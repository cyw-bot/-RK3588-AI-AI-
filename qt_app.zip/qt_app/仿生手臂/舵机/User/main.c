#include "stm32f10x.h"                 
#include "PWM.h"
#include "OLED.h"
#include "Delay.h"
#include "chuanko.h" 
#include "S.h" 
#include "Fingers.h"

extern char RxBuffer[RX_BUFFER_SIZE];  // �������ݵĻ�����
extern volatile uint8_t RxIndex;   // �������ݵ�����
extern uint8_t data_received;
extern uint16_t x1,x2,x3,x4,x5;
float Angle1=60;
float Angle2=60;
float Angle3=60;
float Angle4=60;
float Angle5=60;
uint8_t num;
uint8_t shi,bu,jian,others;
uint8_t flag=0;
uint8_t r=0;
int i,i1,i2,i3;

int main(void)
{
	PWM_Init();
	USART1_Init();
  NVIC_EnableIRQ(USART1_IRQn);
	Servo_Init();
	TIM4_Init();
	Delay_ms(1000);
  while (1) 
	{
		Process_Received_Data();
		if(flag == 0)
		{
			Process_Received_Data();
			if(x1 == 0)
				Servo_SetFingers5(143);      //��Ĵָ 50-143
			if(x2 == 0)
				Servo_SetFingers1(160);      //ʳָ   60-160
			if(x3 == 0)
				Servo_SetFingers4(175);      //��ָ   60-175
			if(x4 == 0)
				Servo_SetFingers3(160);      //����ָ 65-160
			if(x5 == 0)
				Servo_SetFingers2(160);      //СĴָ 65-160
			if(x1 == 1)
				Servo_SetFingers5(50);      //��Ĵָ 50-143
			if(x2 == 1)
				Servo_SetFingers1(60);      //ʳָ   60-160
			if(x3 == 1)
				Servo_SetFingers4(60);      //��ָ   60-175
			if(x4 == 1)
				Servo_SetFingers3(65);      //����ָ 65-160
			if(x5 == 1)
				Servo_SetFingers2(65);      //СĴָ 65-160
		}
		if(flag == 3)
		{
			Servo_SetFingers5(50);      //��Ĵָ 50-143
			Servo_SetFingers1(60);      //ʳָ   60-160
			Servo_SetFingers4(60);      //��ָ   60-175
			Servo_SetFingers3(65);      //����ָ 65-160
			Servo_SetFingers2(65);      //СĴָ 65-160
			Hand_Action();
		}
		if(flag == 4)
		{
				Servo_SetFingers5(143);      //��Ĵָ 50-143
				Servo_SetFingers1(60);      //ʳָ   60-160
				Servo_SetFingers4(60);      //��ָ   60-175
				Servo_SetFingers3(160);      //����ָ 65-160
				Servo_SetFingers2(160);      //СĴָ 65-160
		}
		if(flag == 5)
		{
				Servo_SetFingers5(50);      //��Ĵָ 50-143
				Servo_SetFingers1(60);      //ʳָ   60-160
				Servo_SetFingers4(60);      //��ָ   60-175
				Servo_SetFingers3(65);      //����ָ 65-160
				Servo_SetFingers2(65);      //СĴָ 65-160
		}
	}		
}


			


