#!/usr/bin/env python3
"""YOLO subprocess - 独立进程运行RKNN推理，通过共享文件输出帧"""
import sys, os, time, json, signal

sys.path.insert(0, '/userdata/python_packages')
sys.path.insert(0, '/userdata/hand')
import numpy as np
import cv2

SHARED_DIR = "/tmp/yolo_shared"
os.makedirs(SHARED_DIR, exist_ok=True)

running = True

def on_stop(sig, frame):
    global running
    running = False

signal.signal(signal.SIGTERM, on_stop)
signal.signal(signal.SIGINT, on_stop)

# Load model
print("[yolo_server] Loading model...", flush=True)
from ultralytics import YOLO
model = YOLO("/userdata/hand/yolo11n_rknn_model", task="detect")
print("[yolo_server] Model loaded", flush=True)

# Open camera
cap = None
for dev in [11, 21, 22, 0]:
    cap = cv2.VideoCapture(dev)
    if cap.isOpened():
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        print(f"[yolo_server] Camera: /dev/video{dev}", flush=True)
        break
    cap.release()

if cap is None:
    print("[yolo_server] ERROR: no camera", flush=True)
    sys.exit(1)

prev_time = time.time()
fps = 0
frame_count = 0

while running:
    # Check stop signal
    if os.path.exists(os.path.join(SHARED_DIR, "stop")):
        break

    ret, frame = cap.read()
    if not ret:
        continue

    # Inference on smaller frame for speed
    frame_small = cv2.resize(frame, (320, 320))
    results = model(frame_small, conf=0.25, verbose=False)
    annotated = results[0].plot()

    # FPS
    curr_time = time.time()
    elapsed = curr_time - prev_time
    prev_time = curr_time
    if elapsed > 0:
        fps = 0.9 * fps + 0.1 * (1.0 / elapsed)

    cv2.putText(annotated, "YOLO11n FPS:{:.1f}".format(fps), (5, 20),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

    # Resize to display size
    annotated = cv2.resize(annotated, (640, 480))

    # Atomic write: tmp first, then rename
    tmp_path = os.path.join(SHARED_DIR, "frame_tmp.jpg")
    final_path = os.path.join(SHARED_DIR, "frame.jpg")
    cv2.imwrite(tmp_path, annotated, [cv2.IMWRITE_JPEG_QUALITY, 85])
    os.rename(tmp_path, final_path)  # atomic on Linux

    # Status
    frame_count += 1
    if frame_count % 5 == 0:
        with open(os.path.join(SHARED_DIR, "status.json"), "w") as f:
            json.dump({"fps": round(fps, 1), "frame": frame_count}, f)

cap.release()
print("[yolo_server] Exit", flush=True)
