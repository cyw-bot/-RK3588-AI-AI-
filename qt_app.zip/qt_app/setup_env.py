
# -*- coding: utf-8 -*-
"""
Qt项目环境初始化
在Qt主程序中最先调用: import setup_env
"""
import sys
import os

_PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))

# ═══════════════════════════════════════════
# 第1步：确保系统numpy优先加载（兼容opencv/mediapipe）
# ═══════════════════════════════════════════
import numpy as np

# ═══════════════════════════════════════════
# 第2步：python_packages（ultralytics, torch等）- 项目内软链接
# ═══════════════════════════════════════════
_PY_PKGS = os.path.join(_PROJECT_DIR, "python_packages")
if os.path.isdir(_PY_PKGS) and _PY_PKGS not in sys.path:
    sys.path.insert(0, _PY_PKGS)

# ═══════════════════════════════════════════
# 第3步：hand目录（librknnrt.so, 模型文件等）- 项目内软链接
# ═══════════════════════════════════════════
_HAND_DIR = os.path.join(_PROJECT_DIR, "hand")
if os.path.isdir(_HAND_DIR) and _HAND_DIR not in sys.path:
    sys.path.insert(0, _HAND_DIR)

# ═══════════════════════════════════════════
# 第4步：ASR/TTS venv（追加末尾，保留系统numpy优先）
# ═══════════════════════════════════════════
_VENV_SITE = os.path.join(_PROJECT_DIR, "asr-llm-tts-api/venv/lib/python3.10/site-packages")
if os.path.isdir(_VENV_SITE) and _VENV_SITE not in sys.path:
    sys.path.append(_VENV_SITE)

print("[setup_env] 环境初始化完成")
print(f"  numpy: {np.__version__}")
print(f"  python_packages: {'OK' if os.path.isdir(_PY_PKGS) else 'MISSING'}")
print(f"  hand: {'OK' if os.path.isdir(_HAND_DIR) else 'MISSING'}")
print(f"  asr-llm-tts venv: {'OK' if os.path.isdir(_VENV_SITE) else 'MISSING'}")

