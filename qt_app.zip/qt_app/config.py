# -*- coding: utf-8 -*-
"""
API 密钥配置文件
请填入你申请的 API 密钥
"""
# ==================== 阿里云配置 ====================
# 阿里云语音服务（ASR + TTS）
ALIYUN_APPKEY = "your_aliyun_appkey_here"
ALIYUN_ACCESS_KEY_ID = "your_aliyun_access_key_id_here"
ALIYUN_ACCESS_KEY_SECRET = "your_aliyun_access_key_secret_here"
# 通义千问（LLM + 视觉理解）
DASHSCOPE_API_KEY = "your_dashscope_api_key_here"
# ==================== 百度配置（备选） ====================
BAIDU_APP_ID = "your_app_id_here"
BAIDU_API_KEY = "your_api_key_here"
BAIDU_SECRET_KEY = "your_secret_key_here"
QIANFAN_API_KEY = "your_qianfan_api_key_here"
QIANFAN_SECRET_KEY = "your_qianfan_secret_key_here"
# ==================== 讯飞配置（备选） ====================
XFYUN_APPID = "your_appid_here"
XFYUN_API_KEY = "your_api_key_here"
XFYUN_API_SECRET = "your_api_secret_here"
# ==================== 录音硬件参数（匹配ES8388声卡） ====================
SAMPLE_RATE = 48000
CHANNELS = 2
RECORD_SECONDS = 5
# LLM 参数
LLM_MAX_TOKENS = 200
LLM_TEMPERATURE = 0.7
LLM_SYSTEM_PROMPT = "你是一个友好的语音助手，用简洁的中文回答问题，每次回复控制在500字以内。"
