#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
桌面AI陪伴型仿生手 - RK3588 嵌入式平台
功能：手势识别 | YOLO目标检测 | 语音对话
"""

import sys
import os
import time
from datetime import datetime

# 项目环境初始化
_PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))

# 第1步：先导入系统numpy（兼容opencv/mediapipe）
import numpy as np

# 第2步：添加python_packages（ultralytics, torch等）
_PY_PKGS = os.path.join(_PROJECT_DIR, "python_packages")
if os.path.isdir(_PY_PKGS) and _PY_PKGS not in sys.path:
    sys.path.insert(0, _PY_PKGS)

# 第3步：hand目录
_HAND_DIR = os.path.join(_PROJECT_DIR, "hand")
if os.path.isdir(_HAND_DIR) and _HAND_DIR not in sys.path:
    sys.path.insert(0, _HAND_DIR)

# 第4步：venv路径（dashscope, pyaudio, soundfile, librosa）
# numpy已在第1步缓存为系统版本，venv的2.x不会覆盖
_VENV_SITE = os.path.join(_PROJECT_DIR, "asr-llm-tts-api/venv/lib/python3.10/site-packages")
if os.path.isdir(_VENV_SITE) and _VENV_SITE not in sys.path:
    sys.path.insert(0, _VENV_SITE)

import cv2
import subprocess as _sp
import signal as _signal

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QTextEdit, QFrame, QSizePolicy, QMessageBox,
    QFileDialog, QAction, QGraphicsOpacityEffect
)
from PyQt5.QtCore import (
    Qt, QTimer, pyqtSignal, QPropertyAnimation, QRect, QPoint, QObject,
    QThread, QParallelAnimationGroup, QEasingCurve
)
from PyQt5.QtGui import QImage, QPixmap, QFont, QPainter, QColor, QPen


# ===================== 通用控件：带动画的按钮 =====================
class AnimatedButton(QPushButton):
    def __init__(self, text="", parent=None):
        super().__init__(text, parent)
        self.setCursor(Qt.PointingHandCursor)
        self.size_anim = QPropertyAnimation(self, b"geometry")
        self.size_anim.setDuration(150)

    def enterEvent(self, event):
        rect = self.geometry()
        self.size_anim.setStartValue(rect)
        self.size_anim.setEndValue(QRect(rect.x()-2, rect.y()-2, rect.width()+4, rect.height()+4))
        self.size_anim.start()
        super().enterEvent(event)

    def leaveEvent(self, event):
        rect = self.geometry()
        self.size_anim.setStartValue(rect)
        self.size_anim.setEndValue(QRect(rect.x()+2, rect.y()+2, rect.width()-4, rect.height()-4))
        self.size_anim.start()
        super().leaveEvent(event)

    def mousePressEvent(self, event):
        self.size_anim.stop()
        rect = self.geometry()
        self.size_anim.setStartValue(rect)
        self.size_anim.setEndValue(QRect(rect.x()+1, rect.y()+1, rect.width()-2, rect.height()-2))
        self.size_anim.start()
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        self.size_anim.stop()
        rect = self.geometry()
        self.size_anim.setStartValue(rect)
        self.size_anim.setEndValue(QRect(rect.x()-1, rect.y()-1, rect.width()+2, rect.height()+2))
        self.size_anim.start()
        super().mouseReleaseEvent(event)


# ===================== 通用控件：加载旋转动画 =====================
class LoadingSpinner(QWidget):
    def __init__(self, parent=None, size=40, color="#2d8cf0"):
        super().__init__(parent)
        self.setFixedSize(size, size)
        self.color = QColor(color)
        self.angle = 0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.rotate)
        self.timer.setInterval(30)
        self.hide()

    def start(self):
        self.timer.start()
        self.show()

    def stop(self):
        self.timer.stop()
        self.hide()

    def rotate(self):
        self.angle = (self.angle + 30) % 360
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.translate(self.width()/2, self.height()/2)
        painter.rotate(self.angle)
        pen = QPen(self.color, 3)
        pen.setCapStyle(Qt.RoundCap)
        painter.setPen(pen)
        painter.drawArc(-self.width()/2+4, -self.height()/2+4,
                        self.width()-8, self.height()-8, 0, 270 * 16)
        painter.end()


# ===================== 通用控件：Toast轻提示 =====================
class Toast(QWidget):
    def __init__(self, parent=None, text="", duration=2000):
        super().__init__(parent)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Tool | Qt.WindowStaysOnTopHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.duration = duration
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.label = QLabel(text)
        self.label.setStyleSheet("""
            QLabel {
                background-color: rgba(50, 50, 50, 0.85);
                color: white;
                padding: 10px 20px;
                border-radius: 6px;
                font-size: 14px;
            }
        """)
        self.label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.label)
        self.adjustSize()
        self.anim = QPropertyAnimation(self, b"windowOpacity")
        self.anim.setDuration(300)

    def show_toast(self, parent_widget):
        x = parent_widget.x() + parent_widget.width() - self.width() - 20
        y = parent_widget.y() + parent_widget.height() - self.height() - 30
        self.move(x, y)
        self.anim.setStartValue(0)
        self.anim.setEndValue(1)
        self.anim.start()
        self.show()
        QTimer.singleShot(self.duration, self.hide_toast)

    def hide_toast(self):
        self.anim.setStartValue(1)
        self.anim.setEndValue(0)
        self.anim.finished.connect(self.close)
        self.anim.start()


# ===================== 工作线程1：手势识别 =====================
class HandGestureWorker(QObject):
    frame_ready = pyqtSignal(QImage)
    finger_state = pyqtSignal(list)
    uart_sent = pyqtSignal(list)
    error_occurred = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self.running = False
        self.cap = None
        self.ser = None
        self.hands = None
        self.mp_hands = None
        self.mp_drawing = None

    def init_hand(self):
        import mediapipe as mp
        import serial as pyserial
        self.mp_hands = mp.solutions.hands
        self.mp_drawing = mp.solutions.drawing_utils
        self.hands = self.mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=1,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5
        )
        try:
            self.ser = pyserial.Serial(port='/dev/ttyS9', baudrate=115200, timeout=1)
            time.sleep(0.5)
        except Exception as e:
            raise RuntimeError(f"UART初始化失败: {e}")

    def get_finger_state(self, lm, handedness="Right"):
        fingers = []
        fingers.append(1 if lm.landmark[8].y < lm.landmark[6].y else 0)
        fingers.append(1 if lm.landmark[12].y < lm.landmark[10].y else 0)
        fingers.append(1 if lm.landmark[16].y < lm.landmark[14].y else 0)
        fingers.append(1 if lm.landmark[20].y < lm.landmark[18].y else 0)
        # 根据左右手调整拇指判断（镜像画面中左右手拇指方向相反）
        if handedness == "Left":
            thumb = 1 if lm.landmark[4].x > lm.landmark[3].x else 0
        else:
            thumb = 1 if lm.landmark[4].x < lm.landmark[3].x else 0
        fingers.insert(0, thumb)
        return fingers

    def process(self):
        self.running = True
        self.cap = cv2.VideoCapture("/dev/video21")
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        if not self.cap.isOpened():
            self.error_occurred.emit("无法打开摄像头 /dev/video21")
            return

        last_msg = b""

        while self.running:
            ret, frame = self.cap.read()
            if not ret:
                continue

            frame = cv2.flip(frame, 1)
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = self.hands.process(rgb)

            if results.multi_hand_landmarks:
                hand_lms = results.multi_hand_landmarks[0]
                self.mp_drawing.draw_landmarks(frame, hand_lms, self.mp_hands.HAND_CONNECTIONS)
                handedness = results.multi_handedness[0].classification[0].label
                fingers = self.get_finger_state(hand_lms, handedness)
                self.finger_state.emit(fingers)

                packet = bytearray([0x2C] + [f & 0x01 for f in fingers] + [0x5B])
                if packet != last_msg and self.ser:
                    try:
                        self.ser.write(packet)
                        last_msg = packet
                        self.uart_sent.emit(list(packet))
                    except Exception:
                        pass

            # 转换帧
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            h, w, ch = rgb_frame.shape
            q_img = QImage(rgb_frame.data, w, h, ch * w, QImage.Format_RGB888)
            self.frame_ready.emit(q_img)

    def stop(self):
        self.running = False
        if self.cap:
            self.cap.release()
        if self.ser:
            self.ser.close()
        if self.hands:
            self.hands.close()


# ===================== 工作线程2：语音对话 =====================
class VoiceWorker(QObject):
    """单线程全流程：录音→ASR→LLM→TTS→播放，通过信号驱动UI状态"""
    status_update = pyqtSignal(str)
    phase_change = pyqtSignal(str)  # "recording" | "processing"
    chat_message = pyqtSignal(str, str, bool)
    finished = pyqtSignal()
    error_occurred = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self._stop_flag = False
        self._cancel_flag = False

    def stop_recording(self):
        self._stop_flag = True

    def cancel_all(self):
        self._cancel_flag = True
        self._stop_flag = True

    def run_pipeline(self):
        """完整流水线（在工作线程中同步执行）"""
        self._stop_flag = False
        self._cancel_flag = False
        try:
            import main_api

            # ——— Phase 1: 录音 ———
            self.phase_change.emit("recording")
            self.status_update.emit("录音中(最长10秒, 可手动停止)...")
            audio_file = main_api.record_audio(
                stop_check=lambda: self._stop_flag,
                max_seconds=10
            )
            if self._cancel_flag:
                self.finished.emit()
                return
            if audio_file is None:
                self.error_occurred.emit("录音太短，请重试")
                self.finished.emit()
                return

            # ——— Phase 2: 识别+思考+合成+播放 ———
            self.phase_change.emit("processing")
            self.status_update.emit("识别中...")
            text = main_api.asr_aliyun(audio_file)
            if self._cancel_flag:
                self.finished.emit()
                return
            if not text or not text.strip():
                self.chat_message.emit("系统", "未识别到语音，请重试", False)
                self.finished.emit()
                return
            self.chat_message.emit("我", text, True)

            self.status_update.emit("观察思考中...")
            # 始终携带摄像头画面，让AI真正"看到"用户
            reply = main_api.describe_camera(prompt="用户说：" + text + "。请结合你看到的画面，用中文简短回复。")
            if self._cancel_flag:
                self.finished.emit()
                return
            self.chat_message.emit("AI助手", reply, False)

            self.status_update.emit("合成语音...")
            output = main_api.tts_aliyun(reply)
            if self._cancel_flag:
                self.finished.emit()
                return

            if output:
                self.phase_change.emit("playing")
                self.status_update.emit("播放中(可打断)...")
                main_api.play_audio(output, stop_check=lambda: self._cancel_flag)

            self.status_update.emit("就绪")
            self.finished.emit()
        except Exception as e:
            self.error_occurred.emit(str(e))
            self.finished.emit()


# ===================== 工作线程2：语音对话 ===================== (was merged, keeping label)


# ===================== 桌面主页 =====================
class DesktopWidget(QWidget):
    open_app = pyqtSignal(int)  # 0=手势, 1=YOLO, 2=语音

    def __init__(self, parent=None):
        super().__init__(parent)
        self.init_ui()

    def init_ui(self):
        self.setStyleSheet("""
            QWidget {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #f0f4f8, stop:1 #d9e2ec);
            }
        """)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(60, 60, 60, 60)

        title = QLabel("桌面AI陪伴型仿生手")
        title.setFont(QFont("Noto Sans CJK SC", 30, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("color: #2c3e50; margin-bottom: 30px;")
        layout.addWidget(title)

        subtitle = QLabel("RK3588 嵌入式AI平台")
        subtitle.setAlignment(Qt.AlignCenter)
        subtitle.setStyleSheet("color: #7f8c8d; font-size: 14px; margin-bottom: 20px;")
        layout.addWidget(subtitle)

        app_layout = QHBoxLayout()
        app_layout.setSpacing(40)
        app_layout.addStretch()

        # 手势识别卡片
        hand_btn = AnimatedButton("✋\n手势识别")
        hand_btn.setFixedSize(150, 150)
        hand_btn.setStyleSheet(self.card_style())
        hand_btn.clicked.connect(lambda: self.open_app.emit(0))
        app_layout.addWidget(hand_btn)

        # YOLO检测卡片
        yolo_btn = AnimatedButton("🎯\n目标检测")
        yolo_btn.setFixedSize(150, 150)
        yolo_btn.setStyleSheet(self.card_style())
        yolo_btn.clicked.connect(lambda: self.open_app.emit(1))
        app_layout.addWidget(yolo_btn)

        # 语音对话卡片
        voice_btn = AnimatedButton("🎤\n语音对话")
        voice_btn.setFixedSize(150, 150)
        voice_btn.setStyleSheet(self.card_style())
        voice_btn.clicked.connect(lambda: self.open_app.emit(2))
        app_layout.addWidget(voice_btn)

        app_layout.addStretch()
        layout.addLayout(app_layout)

        hint = QLabel("点击卡片进入对应功能")
        hint.setAlignment(Qt.AlignCenter)
        hint.setStyleSheet("color: #95a5a6; font-size: 12px; margin-top: 30px;")
        layout.addWidget(hint)
        layout.addStretch()

    def card_style(self):
        return """
            QPushButton {
                background-color: white;
                color: #2c3e50;
                border: none;
                border-radius: 20px;
                font-size: 17px;
                line-height: 1.6;
            }
            QPushButton:hover {
                background-color: #f8f9fa;
            }
            QPushButton:pressed {
                background-color: #e9ecef;
            }
        """


# ===================== 页面1：手势识别 =====================
class HandGestureWidget(QWidget):
    back_to_desktop = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.worker_thread = None
        self.worker = None
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # 标题栏
        title_bar = QFrame()
        title_bar.setFixedHeight(50)
        title_bar.setStyleSheet("background-color: #2c3e50;")
        t_layout = QHBoxLayout(title_bar)
        t_layout.setContentsMargins(15, 0, 15, 0)

        back_btn = AnimatedButton("← 返回")
        back_btn.setFixedSize(80, 32)
        back_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent; color: white;
                border: 1px solid rgba(255,255,255,0.3); border-radius: 6px; font-size: 14px;
            }
            QPushButton:hover { background-color: rgba(255,255,255,0.1); }
        """)
        back_btn.clicked.connect(self.go_back)
        t_layout.addWidget(back_btn)

        title_label = QLabel("手势识别 - MediaPipe")
        title_label.setStyleSheet("color: white; font-size: 16px; font-weight: bold;")
        title_label.setAlignment(Qt.AlignCenter)
        t_layout.addWidget(title_label)

        spacer = QWidget()
        spacer.setFixedWidth(80)
        t_layout.addWidget(spacer)
        layout.addWidget(title_bar)

        # 内容区
        content = QWidget()
        c_layout = QVBoxLayout(content)
        c_layout.setContentsMargins(20, 15, 20, 15)
        c_layout.setSpacing(10)

        self.display_label = QLabel("点击「启动手势识别」开始")
        self.display_label.setAlignment(Qt.AlignCenter)
        self.display_label.setStyleSheet("""
            QLabel {
                background-color: #f0f0f0; border: 2px dashed #cccccc;
                border-radius: 8px; color: #999999; font-size: 14px;
            }
        """)
        self.display_label.setMinimumHeight(350)
        self.display_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        c_layout.addWidget(self.display_label)

        # 状态指示区
        status_layout = QHBoxLayout()
        self.finger_label = QLabel("手指状态: -")
        self.finger_label.setStyleSheet("font-size: 14px; color: #2c3e50; background: transparent;")
        status_layout.addWidget(self.finger_label)

        self.uart_label = QLabel("UART: 待发送")
        self.uart_label.setStyleSheet("font-size: 14px; color: #7f8c8d; background: transparent;")
        status_layout.addWidget(self.uart_label)

        self.status_label = QLabel("状态: 未启动")
        self.status_label.setStyleSheet("font-size: 13px; color: #95a5a6; background: transparent;")
        status_layout.addWidget(self.status_label)
        status_layout.addStretch()
        c_layout.addLayout(status_layout)

        # 按钮
        btn_layout = QHBoxLayout()
        self.start_btn = AnimatedButton("启动手势识别")
        self.start_btn.setFixedHeight(36)
        self.start_btn.clicked.connect(self.start)

        self.stop_btn = AnimatedButton("停止")
        self.stop_btn.setFixedHeight(36)
        self.stop_btn.setEnabled(False)
        self.stop_btn.clicked.connect(self.stop)

        btn_layout.addStretch()
        btn_layout.addWidget(self.start_btn)
        btn_layout.addWidget(self.stop_btn)
        btn_layout.addStretch()
        c_layout.addLayout(btn_layout)
        layout.addWidget(content)

        self.loading = LoadingSpinner(self, color="#2d8cf0")

    def go_back(self):
        self.stop()
        self.back_to_desktop.emit()

    def start(self):
        self.worker_thread = QThread()
        self.worker = HandGestureWorker()
        self.worker.moveToThread(self.worker_thread)

        self.worker_thread.started.connect(self.worker.init_hand)
        self.worker_thread.started.connect(self.worker.process)
        self.worker.frame_ready.connect(self.update_frame)
        self.worker.finger_state.connect(self.update_fingers)
        self.worker.uart_sent.connect(self.update_uart)
        self.worker.error_occurred.connect(self.on_error)

        self.worker_thread.finished.connect(self.worker.deleteLater)
        self.worker_thread.finished.connect(self.worker_thread.deleteLater)

        self.worker_thread.start()
        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.status_label.setText("状态: 运行中")
        self.status_label.setStyleSheet("font-size: 13px; color: #27ae60; background: transparent;")
        Toast(self, "手势识别已启动").show_toast(self.window())

    def stop(self):
        if self.worker:
            self.worker.stop()
        if self.worker_thread and self.worker_thread.isRunning():
            self.worker_thread.quit()
            self.worker_thread.wait(2000)
        self.worker = None
        self.worker_thread = None
        self.display_label.clear()
        self.display_label.setText("点击「启动手势识别」开始")
        self.finger_label.setText("手指状态: -")
        self.uart_label.setText("UART: 待发送")
        self.status_label.setText("状态: 未启动")
        self.status_label.setStyleSheet("font-size: 13px; color: #95a5a6; background: transparent;")
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)

    def update_frame(self, q_img):
        pix = QPixmap.fromImage(q_img).scaled(
            self.display_label.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self.display_label.setPixmap(pix)

    def update_fingers(self, fingers):
        names = ["拇指", "食指", "中指", "无名指", "小指"]
        states = " | ".join(f"{n}:{'伸' if f else '屈'}" for n, f in zip(names, fingers))
        self.finger_label.setText(f"手指状态: {states}")

    def update_uart(self, packet):
        self.uart_label.setText(f"UART发送: {packet}")
        self.uart_label.setStyleSheet("font-size: 14px; color: #27ae60; background: transparent;")

    def on_error(self, msg):
        QMessageBox.warning(self, "错误", msg)
        self.stop()

    def resizeEvent(self, event):
        self.loading.move(
            self.display_label.x() + self.display_label.width() - 50,
            self.display_label.y() + self.display_label.height() - 50)
        super().resizeEvent(event)


# ===================== 页面2：YOLO目标检测 =====================
class YOLOWidget(QWidget):
    back_to_desktop = pyqtSignal()

    _SHARED_DIR = "/tmp/yolo_shared"

    def __init__(self, parent=None):
        super().__init__(parent)
        self._proc = None
        self.timer = QTimer()
        self.timer.timeout.connect(self._read_frame)
        self._fps = "0"
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # 标题栏
        title_bar = QFrame()
        title_bar.setFixedHeight(50)
        title_bar.setStyleSheet("background-color: #2c3e50;")
        t_layout = QHBoxLayout(title_bar)
        t_layout.setContentsMargins(15, 0, 15, 0)

        back_btn = AnimatedButton("← 返回")
        back_btn.setFixedSize(80, 32)
        back_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent; color: white;
                border: 1px solid rgba(255,255,255,0.3); border-radius: 6px; font-size: 14px;
            }
            QPushButton:hover { background-color: rgba(255,255,255,0.1); }
        """)
        back_btn.clicked.connect(self.go_back)
        t_layout.addWidget(back_btn)

        title_label = QLabel("YOLO11n 目标检测 - RKNN NPU")
        title_label.setStyleSheet("color: white; font-size: 16px; font-weight: bold;")
        title_label.setAlignment(Qt.AlignCenter)
        t_layout.addWidget(title_label)

        spacer = QWidget()
        spacer.setFixedWidth(80)
        t_layout.addWidget(spacer)
        layout.addWidget(title_bar)

        content = QWidget()
        c_layout = QVBoxLayout(content)
        c_layout.setContentsMargins(20, 15, 20, 15)
        c_layout.setSpacing(10)

        self.display_label = QLabel("点击「启动目标检测」开始")
        self.display_label.setAlignment(Qt.AlignCenter)
        self.display_label.setStyleSheet("""
            QLabel {
                background-color: #f0f0f0; border: 2px dashed #cccccc;
                border-radius: 8px; color: #999999; font-size: 14px;
            }
        """)
        self.display_label.setMinimumHeight(350)
        self.display_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        c_layout.addWidget(self.display_label)

        self.info_label = QLabel("NPU: 待启动")
        self.info_label.setStyleSheet("font-size: 13px; color: #7f8c8d; background: transparent;")
        c_layout.addWidget(self.info_label)

        btn_layout = QHBoxLayout()
        self.start_btn = AnimatedButton("启动目标检测")
        self.start_btn.setFixedHeight(36)
        self.start_btn.clicked.connect(self.start)

        self.stop_btn = AnimatedButton("停止")
        self.stop_btn.setFixedHeight(36)
        self.stop_btn.setEnabled(False)
        self.stop_btn.clicked.connect(self.stop)

        btn_layout.addStretch()
        btn_layout.addWidget(self.start_btn)
        btn_layout.addWidget(self.stop_btn)
        btn_layout.addStretch()
        c_layout.addLayout(btn_layout)
        layout.addWidget(content)

    def go_back(self):
        self.stop()
        self.back_to_desktop.emit()

    def start(self):
        """启动YOLO子进程"""
        os.makedirs(self._SHARED_DIR, exist_ok=True)
        # 清理旧文件
        for f in ["frame.jpg", "stop", "status.json"]:
            p = os.path.join(self._SHARED_DIR, f)
            if os.path.exists(p):
                os.remove(p)

        server_script = os.path.join(_PROJECT_DIR, "_yolo_server.py")
        self._proc = _sp.Popen(
            ["python3", server_script],
            stdout=_sp.PIPE, stderr=_sp.PIPE,
            cwd=_PROJECT_DIR
        )
        self.info_label.setText("NPU: 启动中...")
        self.timer.start(50)  # 20fps 读取
        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        Toast(self, "目标检测已启动").show_toast(self.window())

    def _read_frame(self):
        """从共享目录读取YOLO输出的帧"""
        frame_path = os.path.join(self._SHARED_DIR, "frame.jpg")
        if not os.path.exists(frame_path):
            return

        try:
            pix = QPixmap(frame_path)
            if not pix.isNull():
                scaled = pix.scaled(self.display_label.size(),
                                    Qt.KeepAspectRatio, Qt.SmoothTransformation)
                self.display_label.setPixmap(scaled)
        except Exception:
            return

        status_path = os.path.join(self._SHARED_DIR, "status.json")
        if os.path.exists(status_path):
            try:
                import json
                with open(status_path) as f:
                    s = json.load(f)
                self._fps = s.get("fps", 0)
                self.info_label.setText("NPU: FPS {:.1f}".format(self._fps))
            except Exception:
                pass

        # 检查子进程是否存活
        if self._proc and self._proc.poll() is not None:
            self.info_label.setText("NPU: 进程异常退出")
            self.stop()

    def stop(self):
        self.timer.stop()
        if self._proc:
            # 发送停止信号
            with open(os.path.join(self._SHARED_DIR, "stop"), "w") as f:
                f.write("1")
            try:
                self._proc.wait(timeout=5)
            except Exception:
                self._proc.kill()
            self._proc = None
        self.display_label.clear()
        self.display_label.setText("点击「启动目标检测」开始")
        self.info_label.setText("NPU: 已停止")
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)


# ===================== 页面3：语音对话 =====================
class VoiceWidget(QWidget):
    back_to_desktop = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._thread = None
        self._worker = None
        self._is_recording = False
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        title_bar = QFrame()
        title_bar.setFixedHeight(50)
        title_bar.setStyleSheet("background-color: #2c3e50;")
        t_layout = QHBoxLayout(title_bar)
        t_layout.setContentsMargins(15, 0, 15, 0)

        back_btn = AnimatedButton("← 返回")
        back_btn.setFixedSize(80, 32)
        back_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent; color: white;
                border: 1px solid rgba(255,255,255,0.3); border-radius: 6px; font-size: 14px;
            }
            QPushButton:hover { background-color: rgba(255,255,255,0.1); }
        """)
        back_btn.clicked.connect(self.go_back)
        t_layout.addWidget(back_btn)

        title_label = QLabel("语音对话 - ASR/LLM/TTS")
        title_label.setStyleSheet("color: white; font-size: 16px; font-weight: bold;")
        title_label.setAlignment(Qt.AlignCenter)
        t_layout.addWidget(title_label)

        spacer = QWidget()
        spacer.setFixedWidth(80)
        t_layout.addWidget(spacer)
        layout.addWidget(title_bar)

        content = QWidget()
        c_layout = QVBoxLayout(content)
        c_layout.setContentsMargins(20, 15, 20, 15)
        c_layout.setSpacing(10)

        self.chat_display = QTextEdit()
        self.chat_display.setReadOnly(True)
        self.chat_display.setStyleSheet("""
            QTextEdit {
                background-color: #fafafa; border: 1px solid #e0e0e0;
                border-radius: 8px; padding: 10px; font-size: 14px;
            }
        """)
        c_layout.addWidget(self.chat_display)

        self.append_message("系统",
            "欢迎使用语音对话！\n点击「开始录音」开始说话，再次点击停止\n最长10秒，支持：阿里云ASR + 通义千问 + 阿里云TTS", False)

        self.st_label = QLabel("状态: 就绪")
        self.st_label.setStyleSheet("font-size: 13px; color: #7f8c8d; background: transparent;")
        c_layout.addWidget(self.st_label)

        # 摄像头预览
        self.cam_label = QLabel("摄像头预览")
        self.cam_label.setAlignment(Qt.AlignCenter)
        self.cam_label.setFixedHeight(150)
        self.cam_label.setStyleSheet("""
            QLabel {
                background-color: #e8e8e8; border: 1px solid #cccccc;
                border-radius: 4px; color: #999; font-size: 12px;
            }
        """)
        self.cam_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        c_layout.addWidget(self.cam_label)

        self._cam_timer = QTimer()
        self._cam_timer.timeout.connect(self._update_cam_preview)
        self._cam_cap = None

        btn_layout = QHBoxLayout()
        self.record_btn = AnimatedButton("开始录音")
        self.record_btn.setFixedHeight(50)
        self.record_btn.setFixedWidth(160)
        self._set_btn_style("ready")
        self.record_btn.clicked.connect(self._on_record_btn)
        btn_layout.addStretch()
        btn_layout.addWidget(self.record_btn)
        btn_layout.addStretch()
        c_layout.addLayout(btn_layout)
        layout.addWidget(content)

        self.loading = LoadingSpinner(self, color="#e74c3c")

    def showEvent(self, event):
        super().showEvent(event)
        QTimer.singleShot(300, self._start_cam_preview)

    def hideEvent(self, event):
        self._stop_cam_preview()
        super().hideEvent(event)

    def _set_btn_style(self, state):
        if state == "ready":
            self.record_btn.setText("开始录音")
            self.record_btn.setEnabled(True)
            self.record_btn.setStyleSheet("""
                QPushButton {
                    background-color: #e74c3c; color: white; border: none;
                    border-radius: 25px; font-size: 16px; font-weight: bold;
                }
                QPushButton:hover { background-color: #c0392b; }
                QPushButton:disabled { background-color: #bdc3c7; }
            """)
        elif state == "recording":
            self.record_btn.setText("停止录音")
            self.record_btn.setEnabled(True)
            self.record_btn.setStyleSheet("""
                QPushButton {
                    background-color: #e67e22; color: white; border: none;
                    border-radius: 25px; font-size: 16px; font-weight: bold;
                }
                QPushButton:hover { background-color: #d35400; }
            """)
        elif state == "processing":
            self.record_btn.setText("处理中...")
            self.record_btn.setEnabled(False)
        elif state == "playing":
            self.record_btn.setText("打断播放")
            self.record_btn.setEnabled(True)
            self.record_btn.setStyleSheet("""
                QPushButton {
                    background-color: #8e44ad; color: white; border: none;
                    border-radius: 25px; font-size: 16px; font-weight: bold;
                }
                QPushButton:hover { background-color: #7d3c98; }
            """)

    def _on_record_btn(self):
        if self._is_recording:
            # 停止录音
            if self._worker:
                self._worker.stop_recording()
            self._set_btn_style("processing")
            self.st_label.setText("状态: 停止录音...")
            self._is_recording = False
        elif self.record_btn.text() == "打断播放":
            # 打断语音播放
            if self._worker:
                self._worker.cancel_all()
            self._set_btn_style("ready")
            self.st_label.setText("状态: 播放已打断")
        else:
            self._start_pipeline()

    def _start_pipeline(self):
        self._thread = QThread()
        self._worker = VoiceWorker()
        self._worker.moveToThread(self._thread)
        self._thread.started.connect(self._worker.run_pipeline)
        self._worker.phase_change.connect(self._on_phase_change)
        self._worker.status_update.connect(self._update_status)
        self._worker.chat_message.connect(self.append_message)
        self._worker.error_occurred.connect(self._on_error)
        self._worker.finished.connect(self._on_finished)
        self._thread.start()

    def _on_phase_change(self, phase):
        if phase == "recording":
            self._is_recording = True
            self._set_btn_style("recording")
            self.loading.start()
        elif phase == "processing":
            self._is_recording = False
            self._set_btn_style("processing")
            self.loading.stop()
        elif phase == "playing":
            self._is_recording = False
            self._set_btn_style("playing")
            self.loading.stop()

    def _on_error(self, msg):
        self._cleanup()
        self._set_btn_style("ready")
        self._is_recording = False
        self.loading.stop()
        self.st_label.setText(f"状态: {msg}")
        self.append_message("系统", msg, False)

    def _on_finished(self):
        self._cleanup()
        self._set_btn_style("ready")
        self._is_recording = False
        self.loading.stop()

    def _start_cam_preview(self):
        """启动摄像头预览"""
        import cv2
        for dev in [21, 11, 22, 0]:
            cap = cv2.VideoCapture(dev)
            if cap.isOpened():
                cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
                cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
                self._cam_cap = cap
                self._cam_timer.start(100)
                return

    def _stop_cam_preview(self):
        self._cam_timer.stop()
        if self._cam_cap:
            self._cam_cap.release()
            self._cam_cap = None
        self.cam_label.clear()
        self.cam_label.setText("摄像头预览")

    def _update_cam_preview(self):
        if self._cam_cap is None:
            return
        ret, frame = self._cam_cap.read()
        if not ret:
            return
        frame = cv2.flip(frame, 1)
        cv2.imwrite("/tmp/voice_cam.jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 60])
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb.shape
        q_img = QImage(rgb.data, w, h, ch * w, QImage.Format_RGB888)
        pix = QPixmap.fromImage(q_img).scaled(
            self.cam_label.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self.cam_label.setPixmap(pix)

    def _update_status(self, status):
        self.st_label.setText(f"状态: {status}")

    def _cleanup(self):
        if self._thread and self._thread.isRunning():
            self._thread.quit()
            self._thread.wait(3000)
        self._thread = None
        self._worker = None

    def go_back(self):
        if self._worker:
            self._worker.cancel_all()
        self._cleanup()
        self._is_recording = False
        self.loading.stop()
        self._stop_cam_preview()
        self.back_to_desktop.emit()

    def append_message(self, sender, content, is_user=False):
        time_str = datetime.now().strftime("%H:%M:%S")
        if is_user:
            html = f'''
            <div style="margin: 8px 0; text-align: right;">
                <div style="color: #666; font-size: 12px; margin-bottom: 4px;">{sender} · {time_str}</div>
                <div style="display: inline-block; background-color: #2d8cf0; color: white;
                            padding: 8px 12px; border-radius: 8px; max-width: 70%; text-align: left;">
                    {content.replace(chr(10), '<br>')}
                </div>
            </div>'''
        else:
            html = f'''
            <div style="margin: 8px 0; text-align: left;">
                <div style="color: #666; font-size: 12px; margin-bottom: 4px;">{sender} · {time_str}</div>
                <div style="display: inline-block; background-color: white; color: #333;
                            padding: 8px 12px; border-radius: 8px; border: 1px solid #e0e0e0;
                            max-width: 70%;">
                    {content.replace(chr(10), '<br>')}
                </div>
            </div>'''
        self.chat_display.append(html)
        cursor = self.chat_display.textCursor()
        cursor.movePosition(cursor.End)
        self.chat_display.setTextCursor(cursor)

    def resizeEvent(self, event):
        self.loading.move(
            self.chat_display.x() + self.chat_display.width() - 50,
            self.chat_display.y() + self.chat_display.height() - 50)
        super().resizeEvent(event)


# ===================== 主窗口 =====================
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.current_app = -1
        self.is_animating = False
        self.anim_group = QParallelAnimationGroup()
        self.pages = []
        self.opacity_effects = []
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("桌面AI陪伴型仿生手 - RK3588 AI平台")
        self.resize(1000, 650)
        self.setMinimumSize(800, 550)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        self.central_widget = central_widget

        # 桌面层
        self.desktop = DesktopWidget(central_widget)
        self.desktop.open_app.connect(self.open_app)

        # 三功能页面
        self.pages = [
            HandGestureWidget(central_widget),
            YOLOWidget(central_widget),
            VoiceWidget(central_widget),
        ]
        self.opacity_effects = []

        for page in self.pages:
            opacity = QGraphicsOpacityEffect(page)
            page.setGraphicsEffect(opacity)
            opacity.setOpacity(0)
            page.hide()
            page.back_to_desktop.connect(self.close_app)
            self.opacity_effects.append(opacity)

        self.create_menu_bar()
        self.statusBar().showMessage("就绪")

    def resizeEvent(self, event):
        super().resizeEvent(event)
        w = self.central_widget.width()
        h = self.central_widget.height()
        self.desktop.setGeometry(0, 0, w, h)
        if not self.is_animating and self.current_app != -1:
            self.pages[self.current_app].setGeometry(0, 0, w, h)

    def open_app(self, app_index):
        if self.is_animating or self.current_app == app_index:
            return
        self.is_animating = True

        page = self.pages[app_index]
        opacity_effect = self.opacity_effects[app_index]

        # 对应桌面按钮位置
        btn_map = {0: 0, 1: 1, 2: 2}  # index matches card order
        desktop_btns = self.desktop.findChildren(AnimatedButton)
        btn = desktop_btns[app_index] if app_index < len(desktop_btns) else None

        if btn:
            btn_global_pos = btn.mapTo(self.central_widget, QPoint(0, 0))
            start_rect = QRect(btn_global_pos.x(), btn_global_pos.y(), btn.width(), btn.height())
        else:
            start_rect = QRect(300, 200, 400, 300)

        end_rect = QRect(0, 0, self.central_widget.width(), self.central_widget.height())

        page.setGeometry(start_rect)
        opacity_effect.setOpacity(0)
        page.show()
        page.raise_()

        self.anim_group.clear()

        geom_anim = QPropertyAnimation(page, b"geometry")
        geom_anim.setDuration(350)
        geom_anim.setStartValue(start_rect)
        geom_anim.setEndValue(end_rect)
        geom_anim.setEasingCurve(QEasingCurve.OutCubic)
        self.anim_group.addAnimation(geom_anim)

        opacity_anim = QPropertyAnimation(opacity_effect, b"opacity")
        opacity_anim.setDuration(300)
        opacity_anim.setStartValue(0)
        opacity_anim.setEndValue(1)
        opacity_anim.setEasingCurve(QEasingCurve.OutCubic)
        self.anim_group.addAnimation(opacity_anim)

        self.anim_group.finished.connect(lambda: self.on_open_finished(app_index))
        self.anim_group.start()

    def on_open_finished(self, app_index):
        self.current_app = app_index
        self.is_animating = False
        self.anim_group.disconnect()
        self.desktop.hide()

    def close_app(self):
        if self.is_animating or self.current_app == -1:
            return
        self.is_animating = True

        page = self.pages[self.current_app]
        opacity_effect = self.opacity_effects[self.current_app]

        desktop_btns = self.desktop.findChildren(AnimatedButton)
        btn = desktop_btns[self.current_app] if self.current_app < len(desktop_btns) else None

        if btn:
            btn_global_pos = btn.mapTo(self.central_widget, QPoint(0, 0))
            end_rect = QRect(btn_global_pos.x(), btn_global_pos.y(), btn.width(), btn.height())
        else:
            end_rect = QRect(300, 200, 400, 300)

        start_rect = page.geometry()

        self.anim_group.clear()

        geom_anim = QPropertyAnimation(page, b"geometry")
        geom_anim.setDuration(300)
        geom_anim.setStartValue(start_rect)
        geom_anim.setEndValue(end_rect)
        geom_anim.setEasingCurve(QEasingCurve.InCubic)
        self.anim_group.addAnimation(geom_anim)

        opacity_anim = QPropertyAnimation(opacity_effect, b"opacity")
        opacity_anim.setDuration(250)
        opacity_anim.setStartValue(1)
        opacity_anim.setEndValue(0)
        opacity_anim.setEasingCurve(QEasingCurve.InCubic)
        self.anim_group.addAnimation(opacity_anim)

        self.anim_group.finished.connect(lambda: self.on_close_finished(page))
        self.anim_group.start()

    def on_close_finished(self, page):
        page.hide()
        self.current_app = -1
        self.is_animating = False
        self.anim_group.disconnect()
        self.desktop.show()

    def create_menu_bar(self):
        menubar = self.menuBar()
        file_menu = menubar.addMenu("功能(&F)")
        file_menu.addAction("手势识别(&H)", lambda: self.open_app(0), "Ctrl+H")
        file_menu.addAction("目标检测(&Y)", lambda: self.open_app(1), "Ctrl+Y")
        file_menu.addAction("语音对话(&V)", lambda: self.open_app(2), "Ctrl+V")
        file_menu.addSeparator()
        file_menu.addAction("退出(&Q)", self.close, "Ctrl+Q")

        help_menu = menubar.addMenu("帮助(&A)")
        help_menu.addAction("关于", self.show_about)

    def show_about(self):
        QMessageBox.about(self, "关于",
                          "桌面AI陪伴型仿生手 v1.0\n\n"
                          "嵌入式AI交互界面\n"
                          "适配 Orange Pi 5 Pro / RK3588\n\n"
                          "功能:\n"
                          "  - 手势识别 (MediaPipe + UART)\n"
                          "  - 目标检测 (YOLO11n RKNN NPU)\n"
                          "  - 语音对话 (ASR + LLM + TTS)")

    def closeEvent(self, event):
        for page in self.pages:
            if hasattr(page, 'stop'):
                page.stop()
            if hasattr(page, 'go_back'):
                page.go_back()
        super().closeEvent(event)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    font = QFont("Noto Sans CJK SC", 10)
    app.setFont(font)
    window = MainWindow()
    window.showFullScreen()
    sys.exit(app.exec_())
