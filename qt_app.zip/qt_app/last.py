#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import cv2
import mediapipe as mp
import serial
import time

# =========================
# UART9（香橙派5 Pro）
# =========================
ser = serial.Serial(
    port='/dev/ttyS9',   # 按实际改 ttyS7/8/9
    baudrate=115200,
    timeout=1
)

time.sleep(2)

# =========================
# MediaPipe
# =========================
mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils

hands = mp_hands.Hands(
    static_image_mode=False,
    max_num_hands=1,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

# =========================
# 手指状态提取
# =========================
def get_finger_state(lm):
    fingers = []

    fingers.append(1 if lm.landmark[8].y < lm.landmark[6].y else 0)    # index
    fingers.append(1 if lm.landmark[12].y < lm.landmark[10].y else 0)  # middle
    fingers.append(1 if lm.landmark[16].y < lm.landmark[14].y else 0)  # ring
    fingers.append(1 if lm.landmark[20].y < lm.landmark[18].y else 0)  # pinky

    thumb = 1 if lm.landmark[4].x < lm.landmark[3].x else 0
    fingers.insert(0, thumb)

    return fingers

# =========================
# 摄像头
# =========================
cap = cv2.VideoCapture("/dev/video21")
cap.set(3,300)
cap.set(4,300)
last_msg = b""

print("Running... press q to exit")

while True:
    ret, frame = cap.read()
    if not ret:
        continue

    frame = cv2.flip(frame, 1)
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    results = hands.process(rgb)

    if results.multi_hand_landmarks:
        hand_lms = results.multi_hand_landmarks[0]

        mp_drawing.draw_landmarks(frame, hand_lms, mp_hands.HAND_CONNECTIONS)

        fingers = get_finger_state(hand_lms)

        # =========================
        # 🚀 关键：0x2C + 5数据 + 0x5B
        # =========================
        packet = bytearray()

        packet.append(0x2C)  # 帧头

        for f in fingers:
            packet.append(f & 0x01)  # 确保只发0/1

        packet.append(0x5B)  # 帧尾

        # 防重复发送（避免刷屏）
        if packet != last_msg:
            try:
                ser.write(packet)
                last_msg = packet
                print("Send:", list(packet))
            except Exception as e:
                print("UART error:", e)

    cv2.imshow("Hand UART9", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
ser.close()
