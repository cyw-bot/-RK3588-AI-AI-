#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ASR-LLM-TTS API版主程序
使用云端 API 实现语音对话系统
"""
import sys
import os as _os

import numpy as np  # cache system numpy before venv overrides
_PROJECT_DIR = _os.path.dirname(_os.path.abspath(__file__))

# 添加 venv 中的依赖包路径（pyaudio, dashscope, soundfile, librosa）
_VENV_SITE = _os.path.join(_PROJECT_DIR, "asr-llm-tts-api/venv/lib/python3.10/site-packages")
if _os.path.isdir(_VENV_SITE) and _VENV_SITE not in sys.path:
    sys.path.insert(0, _VENV_SITE)

# 添加 python_packages（typing_extensions, requests新版, ultralytics等）
_PY_PKGS = _os.path.join(_PROJECT_DIR, "python_packages")
if _os.path.isdir(_PY_PKGS) and _PY_PKGS not in sys.path:
    sys.path.insert(0, _PY_PKGS)


import os
import wave
import json
import pyaudio
import requests
import dashscope
from pathlib import Path
from config import *

# ==================== 录音功能 ====================
def record_audio(filename="input.wav", stop_check=None, max_seconds=15):
    """录制音频，支持提前停止。stop_check: callable返回True时停止"""
    print(f"🎤 开始录音 (最长{max_seconds}秒，可手动停止)...")
    audio = pyaudio.PyAudio()
    input_device_index = 1  # rockchip,es8388声卡
    stream = audio.open(
        format=pyaudio.paInt16,
        channels=CHANNELS,
        rate=SAMPLE_RATE,
        input=True,
        frames_per_buffer=1024,
        input_device_index=input_device_index
    )
    frames = []
    total_chunks = int(SAMPLE_RATE / 1024 * max_seconds)
    for i in range(total_chunks):
        if stop_check and stop_check():
            break
        try:
            data = stream.read(1024, exception_on_overflow=False)
        except Exception:
            data = stream.read(1024, exception_on_overflow=False)
        frames.append(data)
    stream.stop_stream()
    stream.close()
    audio.terminate()
    actual_sec = len(frames) * 1024 / SAMPLE_RATE
    print(f"✓ 录制了 {actual_sec:.1f} 秒")

    if len(frames) < 10:
        return None  # 太短，无效

    # 保存原始48k双声道临时文件
    raw_temp = "raw_temp.wav"
    wf_raw = wave.open(raw_temp, 'wb')
    wf_raw.setnchannels(CHANNELS)
    wf_raw.setsampwidth(audio.get_sample_size(pyaudio.paInt16))
    wf_raw.setframerate(SAMPLE_RATE)
    wf_raw.writeframes(b''.join(frames))
    wf_raw.close()

    # 转码：48000双声道 → 16000单声道
    import soundfile as sf
    import librosa
    import numpy as np
    data, sr = sf.read(raw_temp, always_2d=True)
    mono_data = np.mean(data, axis=1)
    data_16k = librosa.resample(mono_data, orig_sr=48000, target_sr=16000)
    # 输出ASR标准音频
    sf.write(filename, data_16k, 16000, format="WAV", subtype="PCM_16")
    os.remove(raw_temp)
    print("✓ 录音完成，已转码为16000单声道")
    return filename
def asr_aliyun(audio_file):
    """阿里云语音识别 - 使用一句话识别 API"""
    print("🔍 正在识别...")

    try:
        import base64
        import hmac
        import hashlib
        import time
        import uuid
        from datetime import datetime
        from urllib.parse import quote

        # 使用阿里云官方签名算法
        timestamp = datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
        nonce = str(uuid.uuid4())

        # 1. 构造规范化请求参数
        params = {
            'AccessKeyId': ALIYUN_ACCESS_KEY_ID,
            'Action': 'CreateToken',
            'Format': 'JSON',
            'SignatureMethod': 'HMAC-SHA1',
            'SignatureNonce': nonce,
            'SignatureVersion': '1.0',
            'Timestamp': timestamp,
            'Version': '2019-02-28'
        }

        # 2. 按字母排序并URL编码
        sorted_params = sorted(params.items())
        canonicalized_query_string = '&'.join([f"{quote(k, safe='')}={quote(v, safe='')}" for k, v in sorted_params])

        # 3. 构造待签名字符串
        string_to_sign = f"GET&{quote('/', safe='')}&{quote(canonicalized_query_string, safe='')}"

        # 4. 计算签名
        h = hmac.new((ALIYUN_ACCESS_KEY_SECRET + '&').encode('utf-8'),
                     string_to_sign.encode('utf-8'),
                     hashlib.sha1)
        signature = base64.b64encode(h.digest()).decode('utf-8')

        # 5. 构造完整URL
        token_url = f"https://nls-meta.cn-shanghai.aliyuncs.com/?{canonicalized_query_string}&Signature={quote(signature, safe='')}"

        token_response = requests.get(token_url, timeout=10)

        if token_response.status_code != 200:
            print(f"✗ Token 获取失败: {token_response.text}")
            return ""

        token_data = token_response.json()
        if 'Token' in token_data:
            token = token_data['Token']['Id']
        else:
            print(f"✗ Token 响应异常: {token_data}")
            return ""

        # 读取并编码音频
        with open(audio_file, 'rb') as f:
            audio_data = f.read()

        # 使用 RESTful API（一句话识别）
        url = "https://nls-gateway.cn-shanghai.aliyuncs.com/stream/v1/asr"

        headers = {
            'Content-Type': 'application/octet-stream',
            'X-NLS-Token': token
        }

        params = {
            'appkey': ALIYUN_APPKEY,
            'format': 'wav',
            'sample_rate': 16000
        }

        response = requests.post(url, headers=headers, params=params, data=audio_data, timeout=10)
        result = response.json()

        # 判断识别结果
        if 'result' in result:
            text = result['result']
            print(f"识别结果: {text}")
            return text
        else:
            print(f"✗ ASR 错误: {result}")
            return ""

    except Exception as e:
        print(f"✗ ASR 错误: {e}")
        import traceback
        traceback.print_exc()
        return ""

# ==================== ASR - 百度语音识别（备选） ====================
def asr_baidu(audio_file):
    """百度语音识别"""
    print("🔍 正在识别...")

    try:
        from aip import AipSpeech

        client = AipSpeech(BAIDU_APP_ID, BAIDU_API_KEY, BAIDU_SECRET_KEY)

        with open(audio_file, 'rb') as f:
            audio_data = f.read()

        result = client.asr(audio_data, 'wav', SAMPLE_RATE, {
            'dev_pid': 1537,  # 普通话
        })

        if result['err_no'] == 0:
            text = result['result'][0]
            print(f"识别结果: {text}")
            return text
        else:
            print(f"✗ ASR 错误: {result['err_msg']}")
            return ""

    except Exception as e:
        print(f"✗ ASR 错误: {e}")
        return ""

# ==================== LLM - 通义千问 ====================
def llm_qwen(prompt):
    """通义千问对话"""
    print("💭 正在思考...")
    try:
        dashscope.api_key = DASHSCOPE_API_KEY.strip()
        # message格式必须用messages传参，不能直接prompt字符串
        messages = [
            {"role": "system", "content": LLM_SYSTEM_PROMPT},
            {"role": "user", "content": prompt}
        ]
        response = dashscope.Generation.call(
            model='qwen-turbo',
            messages=messages,
            seed=1234,
            top_p=0.8,
            result_format='message',
            enable_search=False,
            max_tokens=LLM_MAX_TOKENS,
            temperature=LLM_TEMPERATURE,
            repetition_penalty=1.0
        )
        if response.status_code == 200:
            # message格式正确取值
            reply = response.output.choices[0].message.content.strip()
            print(f"AI回复: {reply}")
            return reply
        else:
            print(f"✗ LLM 错误: {response.code} {response.message}")
            return "抱歉，我现在无法回答。"
    except Exception as e:
        print(f"✗ LLM 异常: {e}")
        import traceback
        traceback.print_exc()
        return "抱歉，我现在无法回答。"

# ==================== LLM - 百度文心一言（备选） ====================
def llm_baidu(prompt):
    """百度文心一言"""
    print("💭 正在思考...")

    try:
        # 获取 access_token
        token_url = f"https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id={QIANFAN_API_KEY}&client_secret={QIANFAN_SECRET_KEY}"
        token_response = requests.get(token_url)
        access_token = token_response.json()['access_token']

        # ��用文心一言
        url = f"https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop/chat/completions?access_token={access_token}"

        payload = {
            "messages": [
                {"role": "user", "content": prompt}
            ],
            "temperature": LLM_TEMPERATURE,
            "max_output_tokens": LLM_MAX_TOKENS
        }

        response = requests.post(url, json=payload)
        result = response.json()

        if 'result' in result:
            reply = result['result']
            print(f"AI回复: {reply}")
            return reply
        else:
            print(f"✗ LLM 错误: {result}")
            return "抱歉，我现在无法回答。"

    except Exception as e:
        print(f"✗ LLM 错误: {e}")
        return "抱歉，我现在无法回答。"

# ==================== TTS - 阿里云语音合成 ====================
# ==================== TTS - 阿里云语音合成（修复版，带标准POP签名） ====================
def tts_aliyun(text, output_file="output.mp3"):
    """阿里云语音合成（修复签名鉴权空白返回问题）"""
    print("🔊 正在合成语音...")
    try:
        import base64
        import hmac
        import hashlib
        import uuid
        import json
        from datetime import datetime
        from urllib.parse import quote

        ak_id = ALIYUN_ACCESS_KEY_ID.strip()
        ak_sec = ALIYUN_ACCESS_KEY_SECRET.strip()
        appkey = ALIYUN_APPKEY.strip()

        # 标准POP签名参数（和ASR保持一致）
        timestamp = datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
        nonce = str(uuid.uuid4())
        params = {
            'AccessKeyId': ak_id,
            'Action': 'CreateToken',
            'Format': 'JSON',
            'SignatureMethod': 'HMAC-SHA1',
            'SignatureNonce': nonce,
            'SignatureVersion': '1.0',
            'Timestamp': timestamp,
            'Version': '2019-02-28'
        }
        # 参数排序+URL编码
        sorted_params = sorted(params.items())
        canonicalized_query_string = '&'.join([
            f"{quote(k, safe='')}={quote(v, safe='')}"
            for k, v in sorted_params
        ])
        # 构造待签名字符串
        string_to_sign = f"GET&{quote('/', safe='')}&{quote(canonicalized_query_string, safe='')}"
        # HMAC-SHA1签名计算
        h = hmac.new(
            (ak_sec + '&').encode('utf-8'),
            string_to_sign.encode('utf-8'),
            hashlib.sha1
        )
        signature = base64.b64encode(h.digest()).decode('utf-8')
        # 完整请求URL
        token_url = (
            f"https://nls-meta.cn-shanghai.aliyuncs.com/?{canonicalized_query_string}"
            f"&Signature={quote(signature, safe='')}"
        )

        token_response = requests.get(token_url, timeout=10)
        raw_text = token_response.text.strip()
        print("[DEBUG] Token接口返回原文：", repr(raw_text))

        # 判空，防止解析空白报错
        if not raw_text:
            print("✗ Token接口返回空白，签名/账号/时间异常")
            return None
        token_data = json.loads(raw_text)

        if "Token" not in token_data:
            print(f"✗ Token获取失败：{token_data}")
            return None
        token = token_data["Token"]["Id"]

        # TTS合成请求
        url = "https://nls-gateway.cn-shanghai.aliyuncs.com/stream/v1/tts"
        headers = {
            'Content-Type': 'application/json',
            'X-NLS-Token': token
        }
        payload = {
            'appkey': appkey,
            'text': text,
            'format': 'mp3',
            'voice': 'xiaoyun',
            'sample_rate': 16000,
            'volume': 50,
            'speech_rate': 0,
            'pitch_rate': 0
        }
        response = requests.post(url, headers=headers, json=payload, timeout=15)
        # 判断返回音频二进制
        if response.status_code == 200 and "audio/mpeg" in response.headers.get("Content-Type", ""):
            with open(output_file, 'wb') as f:
                f.write(response.content)
            print("✓ 语音合成完成")
            return output_file
        else:
            print(f"✗ TTS合成接口失败，返回：{response.text}")
            return None
    except Exception as e:
        print(f"✗ TTS 错误: {e}")
        import traceback
        traceback.print_exc()
        return None
# ==================== 播放音频 ====================
_playback_process = None

def stop_playback():
    """打断当前播放"""
    global _playback_process
    if _playback_process and _playback_process.poll() is None:
        _playback_process.kill()
        _playback_process.wait()
        _playback_process = None
        print("✓ 播放已打断")

def play_audio(filename, stop_check=None):
    """播放音频文件，支持stop_check回调打断"""
    global _playback_process
    print("▶ 正在播放...")

    try:
        import subprocess

        if filename.endswith('.mp3'):
            cmd = ['mpg123', '-q', '-a', 'hw:1,0', filename]
        else:
            cmd = ['aplay', '-q', '-D', 'hw:1,0', filename]

        _playback_process = subprocess.Popen(cmd)

        # 轮询等待播放完成或被中断
        while _playback_process.poll() is None:
            if stop_check and stop_check():
                _playback_process.kill()
                _playback_process.wait()
                _playback_process = None
                print("✓ 播放被打断")
                return None
            import time
            time.sleep(0.1)

        _playback_process = None
        print("✓ 播放完成")

    except FileNotFoundError:
        print("✗ 请安装播放器: sudo apt install mpg123")
        _playback_process = None
    except Exception as e:
        print(f"✗ 播放错误: {e}")
        _playback_process = None


# ==================== 视觉理解 - 通义千问多模态 ====================
import base64 as _base64

def describe_camera(prompt="你看到了什么？请用中文简短描述。", image_path=None):
    """让AI描述摄像头画面，使用qwen3.5-omni-plus-2026-03-15全模态模型"""
    print("📷 正在观察...")
    try:
        import os as _os
        import cv2 as _cv2
        import tempfile
        import time

        if image_path is None:
            shared_frame = "/tmp/voice_cam.jpg"
            if _os.path.exists(shared_frame):
                # 读取共享帧并加水印防止API缓存
                frame = _cv2.imread(shared_frame)
                if frame is None:
                    cap = _cv2.VideoCapture("/dev/video21")
                    if not cap.isOpened():
                        for dev in [11, 22, 0]:
                            cap = _cv2.VideoCapture(dev)
                            if cap.isOpened():
                                break
                    if not cap.isOpened():
                        return "抱歉，我无法打开摄像头。"
                    ret, frame = cap.read()
                    cap.release()
                    if not ret:
                        return "抱歉，摄像头没有画面。"
                # 在右下角加微小时间戳水印，使每张图内容唯一
                ts = str(time.time())
                h, w = frame.shape[:2]
                _cv2.putText(frame, ts, (w-120, h-5),
                            _cv2.FONT_HERSHEY_SIMPLEX, 0.25, (0, 0, 0), 1)
                tmp = tempfile.NamedTemporaryFile(suffix=".jpg", delete=False)
                _cv2.imwrite(tmp.name, frame, [_cv2.IMWRITE_JPEG_QUALITY, 70])
                image_path = tmp.name
            else:
                cap = _cv2.VideoCapture("/dev/video21")
                if not cap.isOpened():
                    for dev in [11, 22, 0]:
                        cap = _cv2.VideoCapture(dev)
                        if cap.isOpened():
                            break
                if not cap.isOpened():
                    return "抱歉，我无法打开摄像头。"
                ret, frame = cap.read()
                cap.release()
                if not ret:
                    return "抱歉，摄像头没有画面。"
                tmp = tempfile.NamedTemporaryFile(suffix=".jpg", delete=False)
                _cv2.imwrite(tmp.name, frame, [_cv2.IMWRITE_JPEG_QUALITY, 70])
                image_path = tmp.name

        dashscope.api_key = DASHSCOPE_API_KEY.strip()

        messages = [{
            "role": "user",
            "content": [
                {"image": image_path},
                {"text": prompt}
            ]
        }]

        response = dashscope.MultiModalConversation.call(
            model="qwen3.5-omni-plus-2026-03-15",
            messages=messages
        )

        if response.status_code == 200:
            raw = response.output.choices[0].message.content
            if isinstance(raw, list):
                if len(raw) > 0 and isinstance(raw[0], dict):
                    reply = raw[0].get("text", "")
                elif len(raw) > 0:
                    reply = str(raw[0])
                else:
                    reply = ""
            elif isinstance(raw, str):
                reply = raw
            else:
                reply = str(raw)
            print("AI观察: " + reply)
            return reply.strip()
        else:
            code = getattr(response, "code", "")
            msg = getattr(response, "message", "")
            print("视觉失败: status=" + str(response.status_code) + " code=" + str(code) + " msg=" + str(msg))
            return "抱歉，视觉服务暂时不可用。"

    except Exception as e:
        print("视觉错误: " + str(e))
        import traceback
        traceback.print_exc()
        return "抱歉，视觉模块出了点问题。"



def main():
    print("=" * 60)
    print("  ASR-LLM-TTS 语音对话系统 (API版)")
    print("  Orange Pi 5 Pro")
    print("=" * 60)
    print("\n使用说明:")
    print("- 按 Enter 开始录音")
    print("- 输入 'q' 退出\n")

    # 检查配置
    if "your_" in DASHSCOPE_API_KEY:
        print("⚠ 警告: 请先在 config.py 中配置 API 密钥")
        return

    print(f"当前使用: 阿里云 ASR + 通义千问 + 阿里云 TTS\n")

    while True:
        user_input = input(">>> 按 Enter 开始录音 (q退出): ")
        if user_input.lower() == 'q':
            break

        try:
            # 1. 录音
            audio_file = record_audio()

            # 2. 语音识别
            text = asr_aliyun(audio_file)
            # text = asr_baidu(audio_file)  # 切换到百度

            if not text.strip():
                print("✗ 未识别到语音，请重试\n")
                continue

            # 3. LLM 对话
            reply = llm_qwen(text)
            # reply = llm_baidu(text)  # 切换到百度

            # 4. 语音合成
            output_audio = tts_aliyun(reply)
            # output_audio = tts_baidu(reply)  # 切换到百度

            # 5. 播放
            if output_audio:
                play_audio(output_audio)

            print("-" * 60 + "\n")

        except KeyboardInterrupt:
            print("\n用户中断")
            break
        except Exception as e:
            print(f"✗ 错误: {e}\n")
            continue

    print("\n再见！")

if __name__ == "__main__":
    main()


