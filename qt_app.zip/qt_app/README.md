# 桌面AI陪伴型仿生手

基于 RK3588 嵌入式平台的端侧多模态 AI 交互系统

## 文件说明

| 文件 | 说明 |
|------|------|
| `qt_main.py` | 主程序 - PyQt5 平板桌面风格交互界面，集成手势识别/目标检测/语音对话三页面 |
| `main_api.py` | 语音对话模块 - ASR语音识别 + LLM大模型对话 + TTS语音合成 + AI视觉理解 |
| `config.py` | 配置文件 - API密钥、录音参数、LLM参数 |
| `last.py` | 手势识别模块 - MediaPipe 21节点手部追踪 + UART串口输出 |
| `yolo_cam_ultra.py` | 目标检测模块 - YOLO11n RKNN NPU 实时推理 |
| `_yolo_server.py` | YOLO子进程服务 - 独立进程运行RKNN推理，通过共享文件输出结果帧 |
| `setup_env.py` | 环境初始化 - Python路径配置与依赖检查 |
| `requirements.txt` | Python依赖清单 |

## 功能概述

### 手势识别
- MediaPipe Hands 21节点实时手部追踪
- 五指独立屈伸判断，左右手自动适配
- UART串口协议输出（115200bps）
- 支持石头剪刀布等手势交互游戏

### 目标检测
- YOLO11n + RK3588 NPU 6TOPS 加速推理
- 80+类常见物体实时检测
- 独立子进程架构，与主UI隔离

### AI语音对话
- 阿里云ASR语音识别 + 通义千问全模态大模型 + 阿里云TTS语音合成
- 完整对话闭环：录音→识别→思考→合成→播放
- AI视觉理解：每次对话自动携带摄像头实时画面
- 支持打断播放

## 运行环境

- **硬件**: Orange Pi 5 Pro (RK3588, 4GB RAM)
- **系统**: Ubuntu 22.04 (aarch64)
- **Python**: 3.10
- **摄像头**: USB RGB摄像头 (/dev/video21)
- **声卡**: ES8388

## 使用方法

1. 将本项目放置在 `/userdata/qt_app/`
2. 配置 `config.py` 中的API密钥
3. 创建资源软链接：
   ```bash
   ln -s /userdata/hand /userdata/qt_app/hand
   ln -s /userdata/python_packages /userdata/qt_app/python_packages
   ln -s /userdata/asr-llm-tts-api /userdata/qt_app/asr-llm-tts-api
   ```
4. 运行：
   ```bash
   DISPLAY=:0 python3 /userdata/qt_app/qt_main.py
   ```

## 技术栈

- **UI**: PyQt5
- **手势**: MediaPipe, pyserial
- **检测**: YOLO11n, RKNN Toolkit Lite2
- **语音**: pyaudio, dashscope
- **视觉理解**: 通义千问 qwen3.5-omni 全模态模型
